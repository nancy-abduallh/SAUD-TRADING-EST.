import { CountUp } from "@/components/effects/CountUp";
import { Reveal } from "@/components/effects/Reveal";
import { Tilt } from "@/components/effects/Tilt";
import { stats } from "@/lib/site-data";

export function StatsBar() {
    return (
        <section id="supply" className="relative z-20 -mt-10 px-5 md:px-8">
            <Reveal className="mx-auto max-w-7xl">
                <div className="gradient-bg-navy rounded-[1.75rem] border border-gold/25 p-2 shadow-[0_40px_80px_-30px_oklch(0.158_0.036_265.6/0.9)] md:p-3">
                    <div className="grid grid-cols-2 gap-2 md:grid-cols-4 md:gap-3">
                        {stats.map(([value, label]) => (
                            <Tilt key={label} max={7} className="rounded-2xl">
                                <div className="glass-dark gold-border rounded-2xl px-4 py-7 text-center md:py-9">
                                    <CountUp value={value} className="depth-md block text-4xl font-bold gradient-text-gold md:text-5xl" />
                                    <span className="depth-sm mt-3 block text-sm text-pearl/70">{label}</span>
                                </div>
                            </Tilt>
                        ))}
                    </div>
                </div>
            </Reveal>
        </section>
    );
}
